import{a as t}from"../chunks/entry.Bgp3H17M.js";export{t as start};
