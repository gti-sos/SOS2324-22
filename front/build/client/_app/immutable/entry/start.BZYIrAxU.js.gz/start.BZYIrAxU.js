import{a as t}from"../chunks/entry.DkkCAbr_.js";export{t as start};
