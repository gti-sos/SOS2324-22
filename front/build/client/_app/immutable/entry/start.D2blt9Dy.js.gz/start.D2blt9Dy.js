import{a as t}from"../chunks/entry.Ciy0l4Y5.js";export{t as start};
