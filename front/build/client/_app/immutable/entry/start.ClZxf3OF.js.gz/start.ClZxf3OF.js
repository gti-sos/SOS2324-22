import{a as t}from"../chunks/entry.BSS9Txnn.js";export{t as start};
