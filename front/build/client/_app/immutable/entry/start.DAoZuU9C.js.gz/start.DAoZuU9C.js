import{a as t}from"../chunks/entry.DBVLXTCG.js";export{t as start};
